import matplotlib.pyplot as plt
import numpy as np
import cv2 as cv
import xlrd
from PIL import Image
import pandas as pd
import os


def calAngle(a, b):
    x = np.array([1, a])
    y = np.array([1, b])
    Lx = np.sqrt(x.dot(x))
    Ly = np.sqrt(y.dot(y))
    # 相当于勾股定理，求得斜线的长度
    cos_angle = x.dot(y) / (Lx * Ly)
    # 求得cos_sita的值再反过来计算，绝对长度乘以cos角度为矢量长度，初中知识。。
    # print(cos_angle)
    angle = np.arccos(cos_angle)
    angle2 = angle * 360 / 2 / np.pi
    # 变为角度
    # print(angle2)
    return angle2


def calIntersection(x1, y1, a1, x2, y2, a2):
    x = (y2 - y1 - a2 * x2 + a1 * x1) / (a1 - a2)
    y = (a1 * a2 * (x2 - x1) + a2 * y1 - a1 * y2) / (a2 - a1)
    return int(x), int(y)

# 定义箱线图识别异常值函数
def box_plot(data_series):
    q_abnormal_low = data_series.quantile(0.25) - 1.5 * (data_series.quantile(0.75) - data_series.quantile(0.25))
    q_abnormal_up = data_series.quantile(0.75) +  1.5 * (data_series.quantile(0.75) - data_series.quantile(0.25))    
    index = (data_series < q_abnormal_low) | (data_series > q_abnormal_up)    
    outliers = data_series.loc[index]
    return outliers.tolist()

def doCobb(imgpath):
    # 导入图片
    img = cv.imread('{0}.jpg'.format(imgpath), cv.IMREAD_UNCHANGED)  # 按原始颜色格式读取图片
    # img = cv.imread('lixin.png', cv.IMREAD_GRAYSCALE) # 按灰度图读取图片
    h, w, _ = img.shape  # 输出：(240, 240, 3)
    print("图片大小")
    print(w, h)
    
    # 计算骨头中点
    readbook = xlrd.open_workbook('{0}detect.xls'.format(imgpath))
    sheet = readbook.sheet_by_name('bone')
    mids=[]
    # d=[]
    for s in range(sheet.nrows):
        bone = sheet.row_values(s)
        mid=((bone[0]+bone[2])/2, (bone[1]+bone[3])/2)
        mids.append(mid)
        # d.append(mid[0])
        
    '''
    # 异常值检测（线箱法）     
    sorted_data = sorted(d)
    print(sorted_data)
    #归一化
    mind = sorted_data[0]
    maxd = sorted_data[-1]
    for i in range(len(sorted_data)):
        sorted_data[i] = (sorted_data[i] - mind)/(maxd-mind)
    print(sorted_data)
    data_series = pd.Series(sorted_data)
    outliers = box_plot(data_series)
    for i in range(len(outliers)):
        outliers[i] = outliers[i]*(maxd-mind)+mind
    print('异常值共有：{0}个，分别是：{1}'.format(len(outliers), outliers))
    for mid in mids:
        for out in outliers:
            if out == mid[0]:
                mids.remove(mid)
    '''
    
    # 骨头中点排序（由上到下）
    mids.sort(key=lambda x:x[1])
    x0=[]
    y0=[]
    for mid in mids:
        x0.append(mid[1])
        y0.append(mid[0])
    print(x0)
    print(y0)
    a = np.polyfit(x0, y0, 5)  # 用5次多项式拟合x，y数组
    b = np.poly1d(a)  # 拟合完之后用这个函数来生成多项式对象
    c = b(x0)  # 生成多项式对象之后，就是获取x在这个多项式处的值
    # 展示拟合曲线
    plt.scatter(x0, y0, marker='o', label='original datas')  # 对原始数据画散点图
    plt.plot(x0, c, ls='--', c='red', label='fitting with second-degree polynomial')  # 对拟合之后的数据，也就是x，c数组画图
    plt.legend()
    path = '{0}matchline.jpg'.format(imgpath)
    if os.path.exists(path):
        os.remove(path)
    plt.savefig('{0}matchline.jpg'.format(imgpath))


    # 求拐点
    f = np.polyder(b, 2)
    arg = np.polyder(a, 2)
    root = np.roots(arg)
    rx=[]
    ry=[]
    for r in root:
        if int(r) <= mids[-1][1] and int(r) >= mids[0][1]:
            rx.append(r)
            ry.append(b(r))
    rx.sort()
    print("端锥坐标：")
    print(rx)
    print(ry)
    m = len(rx)
    print("m")
    print(m)


    # 求切线
    p = []
    for i in range(m):
        p.append((np.polyder(b, 1)(rx[i])))
    print("拐点切线斜率：")
    print(p)


    # 求角画角
    i = 0
    cobbs = [] 
    rm =[]
    while i + 1 < m:
        # 计算cobb角
        print("cobb角: ")
        cobb = calAngle(p[i], p[i + 1])
        print(cobb)
        
        if cobb < 8:
            rm.append(i)
            i = i+1
            continue
        
        cobbs.append(cobb)

        # 计算角顶点
        x, y = calIntersection(rx[i], ry[i], -1 / p[i], rx[i + 1], ry[i + 1], -1 / p[i + 1])
        label = 1 if y < ry[i] else -1
        print("角顶点：")
        print(x, y)

        # 画角的两边（到顶点）
        if y > 0 and y < w:
            cv.circle(img, (y, x), 1, (0, 255, 0), 4)
            cv.line(img, (int(ry[i]), int(rx[i])), (y, x), (0, 0, 255), 1, 4)
            cv.line(img, (int(ry[i + 1]), int(rx[i + 1])), (y, x), (0, 0, 255), 1, 4)
        else:
            # 超出边界，计算与边界交点
            if y < 0:   y = 0
            if y > w:   y = w
            b1 = (y, int((ry[i] - y) * p[i] + rx[i]))
            b2 = (y, int((ry[i + 1] - y) * p[i + 1] + rx[i + 1]))
            cv.line(img, (int(ry[i]), int(rx[i])), b1, (0, 0, 255), 1, 4)
            cv.line(img, (int(ry[i + 1]), int(rx[i + 1])), b2, (0, 0, 255), 1, 4)

        # 画张角
        yy = y + label * 100
        l1 = (yy, int((ry[i] - yy) * p[i] + rx[i]))
        l2 = (yy, int((ry[i + 1] - yy) * p[i + 1] + rx[i + 1]))
        cv.circle(img, l1, 1, (0, 0, 255), 4)
        cv.circle(img, l2, 1, (0, 0, 255), 4)
        print("竖线两点：")
        print(l1, l2)
        cv.line(img, l1, l2, (0, 255, 0), 1, 4)
        text = str(round(cobb, 2)) + ' degree'
        loc = (yy, int((l1[1] + l2[1]) / 2))
        cv.circle(img, loc, 1, (0, 0, 255), 4)
        print("text_loc: ")
        print(loc)
        cv.putText(img, text, loc, cv.FONT_HERSHEY_COMPLEX, 0.5, (0, 255, 0), 1, 4)

        i += 1
    
    for r in rm:
        rx.remove(rx[r])
        ry.remove(ry[r])
    # 画端锥
    for i in range(len(rx)):
        cv.ellipse(img, (int(ry[i]), int(rx[i])), (15, 10), 0, 0, 360, (0, 0, 255), 1, 4)    
        
    img = Image.fromarray(img)
    # outfile = os.path.splitext(imgpath)[0]# + ".jpg"
    # img.show()
    path = '{0}cobbline.jpg'.format(imgpath)
    if os.path.exists(path):
        os.remove(path)
    img.save('{0}cobbline.jpg'.format(imgpath))
    # img.save("%scobbline.jpg"%outfile)
    
    #lenke分型
    ylenke = x0
    top = ylenke[len(ylenke) - 1]
    bot = ylenke[0]
    meddown = (top + bot)/3
    medup = (top + bot)*2/3
    i = 0
    lenks = []
    lenks.append(0)
    lenks.append(2)
    lenks.append(4)
    m = len(rx)
    while i + 1 < m:
        loc = 2
        if (rx[i] + rx[i+1])/2 > medup:
            loc = 0
        elif ((rx[i] + rx[i+1])/2 < medup) & ((rx[i] + rx[i+1])/2 > meddown):
            loc = 2
        elif (rx[i] + rx[i+1])/2 <meddown:
            loc = 4
        if cobbs[i] < 25:
            lenkee = loc
        else:
            lenkee = loc + 1
            
            lenks[int(lenkee/2)] = loc + 1 
        i = i + 1
    lenkeRes = 1
    if (lenks[0] == 0) & (lenks[1] == 3) & (lenks[2] == 4):
        res = 1
    elif (lenks[0] == 1) & (lenks[1] == 3) & (lenks[2] == 4):
        res = 2
    elif (lenks[0] == 0) & (lenks[1] == 3) & (lenks[2] == 5):
        res = 3
    elif (lenks[0] == 1) & (lenks[1] == 3) & (lenks[2] == 5):
        res = 4
    elif (lenks[0] == 0) & (lenks[1] == 2) & (lenks[2] == 5):
        res = 5
    elif (lenks[0] == 0) & (lenks[1] == 3) & (lenks[2] == 5):
        res = 6
        
    print(lenkeRes)
    
    return cobbs,rx,ry,p,lenkeRes