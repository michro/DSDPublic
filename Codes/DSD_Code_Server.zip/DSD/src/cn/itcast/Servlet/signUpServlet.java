package cn.itcast.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.itcast.Bean.User;
import cn.itcast.DAO.UserDAO;

/**
 * Servlet implementation class signUpServlet
 */
@WebServlet("/signUpServlet")
public class signUpServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public signUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");

		boolean flag = true;	// ���շ������Ľ��  �ܷ�ע��ɹ�
		/*
		 * 	���û��������봫��������
		 */
		User user = userDAO.findUser(userName);
		if(user == null)
		{
			userDAO.register(userName, password, 0);
		}
		else {
			flag = false;
		}
			
		if (flag){
			resp.getWriter().write("Sign up successfully!");
			resp.setHeader("refresh", "3;url=/DSD/index.jsp");
		}
		else {
			resp.getWriter().write("Username has been occupied��\nPlease change it!");
			resp.setHeader("refresh", "3;url=/DSD/index.jsp");
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
}
