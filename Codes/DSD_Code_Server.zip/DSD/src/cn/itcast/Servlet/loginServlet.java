package cn.itcast.Servlet;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import cn.itcast.Bean.User;
import cn.itcast.DAO.UserDAO;



@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO = new UserDAO();
	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
//		session.setAttribute("divState", "0");
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");
		
		System.out.println("userName: " + userName);
		System.out.println("password: " + password);
		
		/*
		 * 	���û��������봫��������
		 */
		boolean flag = true;	// ���ܷ��������صĶԴ�
		boolean isDoctor = false;	// ��½���Ƿ�Ϊҽ��
		
		User user = userDAO.findUser(userName);
		if(user == null)
			flag = false;			
		else if(!user.getPassword().equals(password))
		{
			flag = false;
			System.out.println(2);
		}
			
		else if(user.getIs_admin() == 1)
			isDoctor = true;
	
		
		
		if (flag){
			session.setAttribute("userName", userName);
			if(isDoctor){
				resp.sendRedirect("/DSD/doctor.jsp");
			}
			else {
				resp.sendRedirect("/DSD/patient.jsp");
			}
		}
		else {
			resp.getWriter().write("Username or Password is not correct!\nPlease try again!");
			resp.setHeader("refresh", "3;url=/DSD/index.jsp");
		
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
}
