package cn.itcast.Bean;

public class User {
	
	private String Username;
	private String Password;
	private int is_admin; //0 �û� 1 ҽ��
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public int getIs_admin() {
		return is_admin;
	}
	public void setIs_admin(int is_admin) {
		this.is_admin = is_admin;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String username, String password, int is_admin) {
		super();
		Username = username;
		Password = password;
		this.is_admin = is_admin;
	}
	@Override
	public String toString() {
		return "User [Username=" + Username + ", Password=" + Password + ", is_admin=" + is_admin + "]";
	}
	
	
	
}
