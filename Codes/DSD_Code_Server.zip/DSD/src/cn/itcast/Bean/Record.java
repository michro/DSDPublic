package cn.itcast.Bean;

public class Record {
	
	private int Id;
	private String Username;
	private double Codd;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public double getCodd() {
		return Codd;
	}
	public void setCodd(double codd) {
		Codd = codd;
	}
	public Record() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Record(int id, String username, double codd) {
		super();
		Id = id;
		Username = username;
		Codd = codd;
	}
	@Override
	public String toString() {
		return "Record [Id=" + Id + ", Username=" + Username + ", Codd=" + Codd + "]";
	}

	
	
}
