package cn.itcast.Bean;

public class ImgRecord {
	
	private int Id;
	private int RecordId;
	private String PhotoSrc;
	private int Is_Original;
	public int getIs_Original() {
		return Is_Original;
	}
	public void setIs_Original(int is_Original) {
		Is_Original = is_Original;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public int getRecordId() {
		return RecordId;
	}
	public void setRecordId(int recordId) {
		RecordId = recordId;
	}
	public String getPhotoSrc() {
		return PhotoSrc;
	}
	public void setPhotoSrc(String photoSrc) {
		PhotoSrc = photoSrc;
	}
	public ImgRecord(int id, int recordId, String photoSrc, int is_Original) {
		super();
		Id = id;
		RecordId = recordId;
		PhotoSrc = photoSrc;
		Is_Original = is_Original;
	}
	public ImgRecord() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ImgRecord [Id=" + Id + ", RecordId=" + RecordId + ", PhotoSrc=" + PhotoSrc + ", Is_Original="
				+ Is_Original + "]";
	}
	
	
	
}
