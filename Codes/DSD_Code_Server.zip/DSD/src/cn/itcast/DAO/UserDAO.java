package cn.itcast.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.itcast.Bean.User;
import cn.itcast.util.DBUtil;

public class UserDAO {

	private Connection connection;
	
	/**
	 * �����û�����ѯ�û�
	 * @param Username �û���
	 * @return ���ҵ����û�Bean
	 */
	public User findUser(String Username)
	{
		User user = null;
		connection = DBUtil.getConnection();
		String sql = "select * from user where Username = '" + Username + "'";
		PreparedStatement stm = null;
		ResultSet rs = null;
		
		try {
			stm = connection.prepareStatement(sql);
			rs = stm.executeQuery();
			if(rs.next())
			{
				user = new User();
				user.setUsername(rs.getString("Username"));
				user.setPassword(rs.getString("Password"));
				user.setIs_admin(rs.getInt("Is_admin"));
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, rs);
		}
		
		
		return user;
	}
	
	/**
	 * ��������
	 * @param Username �û���
	 * @param Password ����
	 */
	public void updateUser(String Username, String Password)
	{
		connection = DBUtil.getConnection();
		String sql = "update user set Password = ? where Username = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setString(1, Password);
			stm.setString(2, Username);
			stm.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
	/**
	 * ע���û�
	 * @param Username �û���
	 * @param Password ����
	 * @param Is_admin ҽ����ʶ
	 */
	public void register(String Username, String Password, int Is_admin)
	{
		connection = DBUtil.getConnection();
		String sql = "insert into user (Username,Password,Is_admin) values (?,?,?)";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setString(1, Username);
			stm.setString(2, Password);
			stm.setInt(3, Is_admin);
			stm.executeUpdate();
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
	/**
	 * ɾ���û�
	 * @param Username �û���
	 */
	public void deleteUser(String Username)
	{
		Connection connection = DBUtil.getConnection();
		String sql = "delete from user where Username = ?";
		PreparedStatement stm = null;
		try {
			stm = connection.prepareStatement(sql);
			stm.setString(1, Username);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
}
