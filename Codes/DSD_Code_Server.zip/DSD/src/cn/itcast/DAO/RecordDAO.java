package cn.itcast.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import cn.itcast.Bean.Record;
import cn.itcast.util.DBUtil;

public class RecordDAO {

	private Connection  connection;
	
	/**
	 * �����û�����ȡ���м�¼
	 * @param Username �û���
	 * @return
	 */
	public ArrayList<Record> getRecord(String Username)
	{
		ArrayList<Record> records = new ArrayList<Record>();
		connection = DBUtil.getConnection();
		String sql = "select * from record where Username = '" + Username + "'";
		PreparedStatement stm = null;
		ResultSet rs = null;
		
		try {
			stm = connection.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next())
			{
				Record record = new Record();
				record = new Record();
				record.setId(rs.getInt("Id"));
				record.setUsername(rs.getString("Username"));
				record.setCodd(rs.getDouble("Codd"));
				records.add(record);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBUtil.CloseDB(connection, stm, rs);
		}
		
		return records;
	}

	/**
	 * �����¼
	 * @param record �����¼
	 */
	public void writeRecord(Record record)
	{
		connection = DBUtil.getConnection();
		String sql = "insert into record (Id, Username, Codd) values (?,?,?)";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, 0);
			stm.setString(2, record.getUsername());
			stm.setDouble(3, record.getCodd());
			stm.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, null);
		}	
	}

	/**
	 * ���ݼ�¼��Idɾ����¼
	 * @param Id
	 */
	public void deleteRecord(int Id)
	{
		connection = DBUtil.getConnection();
		String sql = "delete from record where Id = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, Id);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
}
