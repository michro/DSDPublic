package cn.itcast.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.itcast.Bean.ImgRecord;
import cn.itcast.Bean.User;
import cn.itcast.util.DBUtil;

public class ImgRecordDAO {
	
	private Connection connection;

	/**
	 * ����recordid��is_originalȡ����¼ͼƬ
	 * @param RecordId
	 * @param Is_Original
	 * @return
	 */
	public ImgRecord findImgRecord(int RecordId, int Is_Original)
	{
		ImgRecord imgRecord = null;
		connection = DBUtil.getConnection();
		String sql = "select * from imgrecord where RecordId = '" + RecordId + "' and Is_Original = '" + Is_Original + "'";		
		PreparedStatement stm = null;
		ResultSet rs = null;
		
		try {
			stm = connection.prepareStatement(sql);
			rs = stm.executeQuery();
			if(rs.next())
			{
				imgRecord = new ImgRecord();
				imgRecord.setId(rs.getInt("Id"));
				imgRecord.setPhotoSrc(rs.getString("PhotoSrc"));
				imgRecord.setRecordId(rs.getInt("RecordId"));
				imgRecord.setIs_Original(rs.getInt("Is_Original"));
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, rs);
		}	
		return imgRecord;
	}
	
	/**
	 * �����¼
	 * @param imgRecord
	 */
	public void writeImgRecord(ImgRecord imgRecord)
	{
		connection = DBUtil.getConnection();
		String sql = "insert into imgrecord (Id, RecordId, PhotoSrc, Is_Original) values (?,?,?,?)";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, 0);
			stm.setInt(2, imgRecord.getRecordId());
			stm.setString(3, imgRecord.getPhotoSrc());
			stm.setInt(4, imgRecord.getIs_Original());
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
	/**
	 * ���ݼ�¼Idɾ����¼
	 * @param RecordId
	 */
	public void deleteImgRecord(int RecordId)
	{
		connection = DBUtil.getConnection();
		String sql = "delete from imgrecord where RecordId = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, RecordId);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
}
