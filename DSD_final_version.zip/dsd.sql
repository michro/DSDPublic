/*
Navicat MySQL Data Transfer

Source Server         : microsteve
Source Server Version : 80015
Source Host           : localhost:3306
Source Database       : dsd

Target Server Type    : MYSQL
Target Server Version : 80015
File Encoding         : 65001

Date: 2020-11-12 10:16:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for algorithmchoose
-- ----------------------------
DROP TABLE IF EXISTS `algorithmchoose`;
CREATE TABLE `algorithmchoose` (
  `algorithmId` int(11) NOT NULL,
  `index` int(11) NOT NULL,
  PRIMARY KEY (`algorithmId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of algorithmchoose
-- ----------------------------
INSERT INTO `algorithmchoose` VALUES ('1', '0');
INSERT INTO `algorithmchoose` VALUES ('2', '0');
INSERT INTO `algorithmchoose` VALUES ('3', '0');

-- ----------------------------
-- Table structure for cobbs
-- ----------------------------
DROP TABLE IF EXISTS `cobbs`;
CREATE TABLE `cobbs` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `imgId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `cobbValue` varchar(255) NOT NULL,
  `x1` varchar(255) NOT NULL,
  `y1` varchar(255) NOT NULL,
  `x2` varchar(255) NOT NULL,
  `y2` varchar(255) NOT NULL,
  `k1` varchar(255) NOT NULL,
  `k2` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of cobbs
-- ----------------------------

-- ----------------------------
-- Table structure for imgrecord
-- ----------------------------
DROP TABLE IF EXISTS `imgrecord`;
CREATE TABLE `imgrecord` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `recordId` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `photoSrc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of imgrecord
-- ----------------------------

-- ----------------------------
-- Table structure for record
-- ----------------------------
DROP TABLE IF EXISTS `record`;
CREATE TABLE `record` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `cobbNums` int(10) NOT NULL,
  `lenkeRes` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of record
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `is_admin` int(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('lisi', '123456', '1');
INSERT INTO `user` VALUES ('zhangsan', '123456', '0');
