package cn.itcast.Servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.itcast.Bean.Cobbs;
import cn.itcast.Bean.ImgRecord;
import cn.itcast.Bean.Record;
import cn.itcast.DAO.CobbsDAO;
import cn.itcast.DAO.ImgRecordDAO;
import cn.itcast.DAO.RecordDAO;
import cn.itcast.DAO.UserDAO;
import sun.misc.BASE64Encoder;

/**
 * Servlet implementation class DisplayHistoryImage
 */
@WebServlet("/DisplayHistoryImage")
@SuppressWarnings("unused")
public class DisplayHistoryImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private UserDAO userDAO = new UserDAO();
	private RecordDAO recordDAO = new RecordDAO();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayHistoryImage() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public static String convertFileToBase64(String imgPath) {
        byte[] data = null;
        // ��ȡͼƬ�ֽ�����
        try {
            InputStream in = new FileInputStream(imgPath);
            System.out.println("�ļ���С���ֽڣ�="+in.available());
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // ���ֽ��������Base64���룬�õ�Base64������ַ���
        BASE64Encoder encoder = new BASE64Encoder();
        String base64Str = encoder.encode(data);
        return base64Str;
    }
    

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
//		String username = (String) session.getAttribute("userName");
		String username = "";
		
		try{
			username = session.getAttribute("userName").toString();
		}catch (Exception e) {
			// TODO: handle exception
			username = request.getParameter("userName");
		}
		
		
		
		System.out.println(username);
		
		// ��ID���������� ��ȡ������ʷ��¼
		RecordDAO recordDAO = new RecordDAO();
		ImgRecordDAO imgRecordDAO = new ImgRecordDAO();
		CobbsDAO cobbsDAO = new CobbsDAO();
		
		//ȡ����Ӧ�ļ�¼
		ArrayList<Record> records = recordDAO.getRecord(username);	
		
		Collections.sort(records, new Comparator<Record>() {
			public int compare(Record record1, Record record2) {
				return record1.getId().compareTo(record2.getId());
			}
		});
				
		String result = "";
		
		for(Record record : records)
		{
			result += " ";
			String id = record.getId();
			int cobbNums = record.getCobbNums();
			int lenkeRes = record.getLenkeRes();
			ImgRecord imgRecord = imgRecordDAO.findImgRecord(id);
			String photoSrc = imgRecord.getPhotoSrc();
			String base64String = convertFileToBase64(photoSrc);
			result = result + base64String + "?" + lenkeRes + "," + cobbNums;
			ArrayList<Cobbs> cobbs = cobbsDAO.findCobbs(imgRecord.getId());
			for(Cobbs cobb: cobbs)
			{
				String cobbValue = cobb.getCobbValue();
				String x1 = cobb.getX1();
				String y1 = cobb.getY1();
				String x2 = cobb.getX2();
				String y2 = cobb.getY2();
				String k1 = cobb.getK1();
				String k2 = cobb.getK2();
				String cobbString = "," + cobbValue + "," + x1 + "," + y1 + "," + k1
						+ "," + x2 + "," + y2 + "," + k2;
				result += cobbString;
			}				
		}			
		PrintWriter writer = response.getWriter();
		if(result != "")
			result = result.substring(1);
        writer.write(result);
	}

}
