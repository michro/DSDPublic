package cn.itcast.Servlet;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.itcast.Bean.Cobbs;
import cn.itcast.DAO.AlgorithmDAO;
import cn.itcast.DAO.CobbsDAO;
import cn.itcast.DAO.ImgRecordDAO;
import cn.itcast.DAO.RecordDAO;

/**
 * Servlet implementation class DoctorModifyDetectServlet
 */
@WebServlet("/DoctorModifyDetectServlet")
public class DoctorModifyDetectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorModifyDetectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		AlgorithmDAO algorithmDAO = new AlgorithmDAO();
		ImgRecordDAO imgRecordDAO = new ImgRecordDAO();
		CobbsDAO cobbsDAO = new CobbsDAO();
		
		String cobb1 = request.getParameter("hb0");
		String x1 = request.getParameter("hb1");
		String y1 = request.getParameter("hb2");
		String k1 = request.getParameter("hb3");
		String x2 = request.getParameter("hb4");
		String y2 = request.getParameter("hb5");
		String k2 = request.getParameter("hb6");	
		
		String cobb2 = request.getParameter("hb7");
		String x3 = request.getParameter("hb8");
		String y3 = request.getParameter("hb9");
		String k3 = request.getParameter("hb10");
		String x4 = request.getParameter("hb11");
		String y4 = request.getParameter("hb12");
		String k4 = request.getParameter("hb13");
		
		
		
		int AlgorithmNum = -1;
		String recordId = "";
		
		try{
			AlgorithmNum = (int)session.getAttribute("chooseAlgorithm");
			recordId = (String)session.getAttribute("recordId");
		}catch (Exception e) {
			// TODO: handle exception
			AlgorithmNum = Integer.parseInt(request.getParameter("chooseAlgorithm"));
			recordId = request.getParameter("recordId");
		}	
		
		
		algorithmDAO.updateAlgorithm(AlgorithmNum, algorithmDAO.findAlgorithm(AlgorithmNum).getIndex() - 1);
		
		
		
		String imgIdString = imgRecordDAO.findImgRecord(recordId).getId();
		cobbsDAO.deleteCobbs(imgIdString);
		
		
		String id = UUID.randomUUID().toString(); 
		Cobbs cobbs1 = new Cobbs(id, imgIdString, cobb1, x1, y1, x2, y2, k1, k2);
		cobbsDAO.writeCobbs(cobbs1);
		if(cobb2 != "")
		{
			String id2 = UUID.randomUUID().toString(); 
			Cobbs cobbs2 = new Cobbs(id2, imgIdString, cobb2, x3, y3, x4, y4, k3, k4);
			cobbsDAO.writeCobbs(cobbs2);
		}
			
		//��ȡlenkeRes��CobbsNum
		int lenkeRes = Integer.parseInt(request.getParameter("finalCobbInput"));
		int cobbNums = Integer.parseInt(request.getParameter("cobb_n"));
//		System.out.println(lenkeRes);
		RecordDAO recordDAO = new RecordDAO();
		recordDAO.update(recordId, cobbNums, lenkeRes);
				
		System.out.println(cobb1 + " " + x1 + " " + y1 + " " + k1 + " " + x2 + " " + y2 + " " + k2);
		System.out.println(cobb2 + " " + x3 + " " + y3 + " " + k3 + " " + x4 + " " + y4 + " " + k4);
		
		response.sendRedirect("/DSD/doctor.jsp");
	}

}
