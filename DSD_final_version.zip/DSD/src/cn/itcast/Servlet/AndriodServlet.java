package cn.itcast.Servlet;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.itcast.Bean.Algorithm;
import cn.itcast.Bean.Cobbs;
import cn.itcast.Bean.ImgRecord;
import cn.itcast.Bean.Record;
import cn.itcast.DAO.AlgorithmDAO;
import cn.itcast.DAO.CobbsDAO;
import cn.itcast.DAO.ImgRecordDAO;
import cn.itcast.DAO.RecordDAO;
import cn.itcast.util.GetTime;
import cn.itcast.util.Java2Py;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * Servlet implementation class DoctorSubmitSinglePic
 */
@WebServlet("/AndriodServlet")
@SuppressWarnings("unused")
public class AndriodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AndriodServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    
    private byte[] loadImage(File file){
        //���ڷ��ص��ֽ�����
        byte[] data=null;
        //���ļ�������
        FileInputStream fin=null;
        //���ֽ������
        ByteArrayOutputStream bout=null;
        try{
            //�ļ���������ȡ��Ӧ�ļ�
            fin=new FileInputStream(file);
            //��������建������С
            bout=new ByteArrayOutputStream((int)file.length());
            //�����ֽ����飬���ڶ�ȡ�ļ���
            byte[] buffer=new byte[1024];
            //���ڱ�ʾ��ȡ��λ��
            int len=-1;
            //��ʼ��ȡ�ļ�
            while((len=fin.read(buffer))!=-1){
                //��buffer�ĵ�0λ�ÿ�ʼ����ȡ����lenλ�ã����д��bout
                bout.write(buffer,0,len);
            }
            //�������תΪ�ֽ�����
            data=bout.toByteArray();
            //�ر����������
            fin.close();
            bout.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return data;
    }
    
    private String byteToString(byte[] data){
        String dataString=null;
        try{
            //���ֽ�����תΪ�ַ����������ʽΪISO-8859-1
            dataString=new String(data,"ISO-8859-1");
        }catch(Exception e){
            e.printStackTrace();
        }
        return dataString;
    }
    
    public static String convertFileToBase64(String imgPath) {
        byte[] data = null;
        // ��ȡͼƬ�ֽ�����
        try {
            InputStream in = new FileInputStream(imgPath);
            System.out.println("�ļ���С���ֽڣ�="+in.available());
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // ���ֽ��������Base64���룬�õ�Base64������ַ���
        BASE64Encoder encoder = new BASE64Encoder();
        String base64Str = encoder.encode(data);
        return base64Str;
    }
    
    public static boolean convertBase64ToFile(String imgStr, String imgFilePath)
    {
    	if(imgStr == null)
    		return false;    	
    	BASE64Decoder decoder = new BASE64Decoder();
    	imgStr = imgStr.split(",")[1];
    	try {
			byte[] bytes = decoder.decodeBuffer(imgStr);
			for(int i = 0; i < bytes.length; i++)
			{
				if(bytes[i] < 0)
				{
					bytes[i] += 256;
				}
			}
			OutputStream out = new FileOutputStream(imgFilePath);
			out.write(bytes);
			out.flush();
			out.close();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}

    	
    	
    	
    }

    public static int chooseAlgorithm()
    {
    	AlgorithmDAO algorithmDAO = new AlgorithmDAO();
    	int algorithm1 = algorithmDAO.findAlgorithm(1).getIndex();
    	int algorithm2 = algorithmDAO.findAlgorithm(2).getIndex();
    	int algorithm3 = algorithmDAO.findAlgorithm(3).getIndex();
    	
    	if(algorithm1 < algorithm2)
    	{
    		if(algorithm2 < algorithm3)
    			return 3;
    		else
    		{
    			return 2;
    		}
    	}
    	else {
			if(algorithm1 > algorithm3)
				return 1;
			else {
				return 3;
			}
		}
    	
    }
    
    
    
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        String username = request.getParameter("submitId");
        System.out.println("submitId = " + username);
        //��ȡajax���ݵĲ������ͻ�ȡ�������ݵķ�ʽһ��
//        String imgStr=request.getParameter("img");
        //String name=request.getParameter("param2");
        
        StringBuffer imgStr = new StringBuffer() ;
        InputStream is = request.getInputStream();
        InputStreamReader isr = new InputStreamReader(is);  
        BufferedReader br = new BufferedReader(isr);
        String s = "" ;
        while((s=br.readLine())!=null){
        	imgStr.append(s) ;
        }
  
        System.out.println("imgstr:" + imgStr);
        
        
        // ��ͼƬ��username����������
        String imgId = UUID.randomUUID().toString();
        String imgFilePath =  "D:\\eclipse-workspace\\DSD\\RecordImg\\" + imgId + ".jpg";
        String transSrc = "D:\\eclipse-workspace\\DSD\\RecordImg\\input.jpg";
        System.out.println(imgFilePath);
        convertBase64ToFile(imgStr.toString(), imgFilePath);
        
        //ѡ���㷨���н�����
        //1 ������
        //2 ������
        //3 ������
        int num = chooseAlgorithm();
        System.out.println("num = " + num);
//        int num = 2;
        session.setAttribute("chooseAlgorithm", num);
        
        //ѡ���㷨�� num ѵ�� ��ý������line��
        String line = "";
        if(num == 2)
        	line = Java2Py.runAlgorithm(num, transSrc);  
        else {
        	line = Java2Py.runAlgorithm(num, imgFilePath);  
		}
             
        System.out.println(line);
        int cobbNums = 0;
        int lenkeRes = 0;
        String[] results = null;
        ArrayList<Cobbs> cobbs = new ArrayList<Cobbs>();
        switch(num)
        {
        case 1:       
        	results = line.split(",");
        	lenkeRes = Integer.parseInt(results[0]);
        	int n = results.length;
        	cobbNums = (n - 1) / 7;        	
        	for(int i = 0; i < cobbNums; i++)
        	{
        		String id = UUID.randomUUID().toString(); 
        		String cobbValue = results[i * 7 + 1];
        		String x1 = results[i * 7 + 2];
        		String y1 = results[i * 7 + 3];
        		String k1 = results[i * 7 + 4];
        		String x2 = results[i * 7 + 5];
        		String y2 = results[i * 7 + 6];
        		String k2 = results[i * 7 + 7];
        		Cobbs cobb = new Cobbs(id, imgId, cobbValue, x1, y1, x2, y2, k1, k2);
        		cobbs.add(cobb);
        	}
        	break;
        case 2:
        	convertBase64ToFile(imgStr.toString(), transSrc);
        	results = line.split(",");
        	lenkeRes = Integer.parseInt(results[0]);
        	cobbNums = Integer.parseInt(results[1]);
        	for(int i = 0; i < cobbNums; i++)
        	{
        		String id = UUID.randomUUID().toString(); 
        		String cobbValue = results[i * 7 + 2];
        		String x1 = results[i * 7 + 3];
        		String y1 = results[i * 7 + 4];
        		String k1 = results[i * 7 + 5];
        		String x2 = results[i * 7 + 6];
        		String y2 = results[i * 7 + 7];
        		String k2 = results[i * 7 + 8];
        		Cobbs cobb = new Cobbs(id, imgId, cobbValue, x1, y1, x2, y2, k1, k2);
        		cobbs.add(cobb);
        	}
        	break;
        case 3:
        	results = line.split(" ");
        	lenkeRes = Integer.parseInt(results[0]);
        	int h = results.length;
        	cobbNums = (h - 1) / 7;        	
        	for(int i = 0; i < cobbNums; i++)
        	{
        		String id = UUID.randomUUID().toString(); 
        		String cobbValue = results[i * 7 + 1];
        		String x1 = results[i * 7 + 2];
        		String y1 = results[i * 7 + 3];
        		String x2 = results[i * 7 + 4];
        		String y2 = results[i * 7 + 5];
        		String k1 = results[i * 7 + 6];
        		String k2 = results[i * 7 + 7];
        		Cobbs cobb = new Cobbs(id, imgId, cobbValue, x1, y1, x2, y2, k1, k2);
        		cobbs.add(cobb);
        	}
        	break;
        }
        
        //ȡ�ý������               
        RecordDAO recordDAO = new RecordDAO();
        String id = GetTime.GetTimeDate();
        session.setAttribute("recordId", id);
        Record record = new Record(id, username, cobbNums, lenkeRes);
        recordDAO.writeRecord(record);
        
        ImgRecordDAO imgRecordDAO = new ImgRecordDAO();
        ImgRecord imgRecord = new ImgRecord(imgId, id, imgFilePath);
        imgRecordDAO.writeImgRecord(imgRecord);
        
        //����cobbs�Ƕ�
        CobbsDAO cobbsDAO = new CobbsDAO();
        for(Cobbs cobb: cobbs)
        {
        	cobbsDAO.writeCobbs(cobb);
        }   
        
        
        // get ѵ�����ͼƬ �ͽǶ�        
        PrintWriter writer = response.getWriter();
        
        String result = "";
        
		result = result + id + "," + lenkeRes + "," + cobbNums +"," + num;
		ArrayList<Cobbs> cobbResults = cobbsDAO.findCobbs(imgRecord.getId());
		for(Cobbs cobb: cobbResults)
		{
			String cobbValue = cobb.getCobbValue();
			String x1 = cobb.getX1();
			String y1 = cobb.getY1();
			String x2 = cobb.getX2();
			String y2 = cobb.getY2();
			String k1 = cobb.getK1();
			String k2 = cobb.getK2();
			String cobbString = "," + cobbValue + "," + x1 + "," + y1 + "," + k1
					+ "," + x2 + "," + y2 + "," + k2;
			result += cobbString;
		}
		writer.write(result);
		
		session.setAttribute("imgData", imgStr);session.setAttribute("codd", lenkeRes);		
		session.setAttribute("doctorInputUserid", username);

        
        System.out.println("get and response image");
	}

}
