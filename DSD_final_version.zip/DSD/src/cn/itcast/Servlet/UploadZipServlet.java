package cn.itcast.Servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import cn.itcast.util.zipUncompress;


/**
 * Servlet implementation class UploadZipServlet
 */
@WebServlet("/UploadZipServlet")
public class UploadZipServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadZipServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		DiskFileItemFactory factory = new DiskFileItemFactory();          
        File f = new File("D:\\eclipse-workspace\\DSD\\TransImg");
        if(!f.exists()) f.mkdirs();
        factory.setRepository(f);        
        ServletFileUpload fileUpload = new ServletFileUpload(factory);
        fileUpload.setHeaderEncoding("utf-8");
        
		try {
            // ���������������ȡ�ļ�����
            List<FileItem> formItems = fileUpload.parseRequest(request);
            FileItem fileItem = formItems.get(0);
            System.out.println(fileItem.getSize());
            
            // ��ȡ�ϴ��ļ���
            String filename = fileItem.getName();
            filename = filename.substring(filename.lastIndexOf("\\") + 1);
            filename = UUID.randomUUID().toString()+"_" + filename;
            String filepath = "D:\\eclipse-workspace\\DSD\\TransImgZip\\" + filename;
            System.out.println(filepath);
            File file = new File(filepath);
            file.getParentFile().mkdirs();
            file.createNewFile();
            InputStream in = fileItem.getInputStream();
            FileOutputStream out = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int len;
            while((len = in.read(buffer)) > 0)
            {
            	out.write(buffer, 0, len);
            } 
            in.close();
        	out.close();
        	fileItem.delete();
        	
        	String filepath2 = "D:\\eclipse-workspace\\DSD\\TransImg";
        	zipUncompress.zipUncompress(filepath, filepath2);
        	
            
        } catch (Exception ex) {
            request.setAttribute("message",
                    "������Ϣ: " + ex.getMessage());
        }
        
		PrintWriter  out = response.getWriter();
		out.print("<script>");
		out.print("alert('success!');");
		out.print("window.location.href='doctor.jsp';");
		out.print("</script>");
		out.close();
		System.out.println("");
	}

}
