package cn.itcast.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import cn.itcast.Bean.Algorithm;
import cn.itcast.util.DBUtil;

public class AlgorithmDAO {
	
	private Connection connection;
	
	/**
	 * ȡ����Ӧ�㷨��Ԫ
	 * @param algorithmId
	 * @return
	 */
	public Algorithm findAlgorithm(int algorithmId)
	{
		Algorithm algorithm = null;
		connection = DBUtil.getConnection();
		String sql = "select * from algorithmChoose where algorithmId = '" + algorithmId + "'";
		PreparedStatement stm = null;
		ResultSet rs = null;
		
		try {
			stm = connection.prepareStatement(sql);
			rs = stm.executeQuery();
			if(rs.next())
			{
				algorithm = new Algorithm(rs.getInt("algorithmId"), rs.getInt("index"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, rs);
		}
		
		return algorithm;
		
	}

	
	/**
	 * д���Ӧ���㷨��Ԫ
	 * @param algorithm
	 */
	public void writeAlgorithm(Algorithm algorithm)
	{
		connection = DBUtil.getConnection();
		String sql = "insert into algorithmChoose (algorithmId, index) values (?, ?)";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, algorithm.getAlgorithmId());
			stm.setInt(2, algorithm.getIndex());
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
	
	/**
	 * �޸Ķ�Ӧ��index
	 * @param algorithmId
	 * @param index
	 */
	public void updateAlgorithm(int algorithmId, int index)
	{
		connection = DBUtil.getConnection();
		String sql = "update algorithmChoose set `index` = ? where `algorithmId` = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, index);
			stm.setInt(2, algorithmId);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
}
