package cn.itcast.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import cn.itcast.Bean.Cobbs;
import cn.itcast.util.DBUtil;

public class CobbsDAO {

	private Connection connection;
	
	/**
	 * ����imgIdȡ��������ص�cobbs��
	 * @param imgId
	 * @return
	 */
	public ArrayList<Cobbs> findCobbs(String imgId)
	{
		ArrayList<Cobbs> cobbs = new ArrayList<Cobbs>();
		connection = DBUtil.getConnection();
		String sql = "select * from cobbs where imgId = '" + imgId + "'";
		PreparedStatement stm = null;
		ResultSet rs = null;
		
		try {
			stm = connection.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next())
			{
				Cobbs cobb = new Cobbs();
				cobb.setId(rs.getString("id"));
				cobb.setImgId(rs.getString("imgId"));
				cobb.setCobbValue(rs.getString("cobbValue"));
				cobb.setX1(rs.getString("x1"));
				cobb.setX2(rs.getString("x2"));
				cobb.setY1(rs.getString("y1"));
				cobb.setY2(rs.getString("y2"));
				cobb.setK1(rs.getString("k1"));
				cobb.setK2(rs.getString("k2"));
				cobbs.add(cobb);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, rs);
		}
		
		return cobbs;
	}


	/**
	 * ����cobbs����Cobbs��
	 * @param cobbs
	 */
	public void writeCobbs(Cobbs cobbs)
	{
		connection = DBUtil.getConnection();
		String sql = "insert into cobbs (id, imgId, cobbValue, x1, y1, x2, y2, k1, k2) values (?,?,?,?,?,?,?,?,?)";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setString(1, cobbs.getId());
			stm.setString(2, cobbs.getImgId());
			stm.setString(3, cobbs.getCobbValue());
			stm.setString(4,cobbs.getX1());
			stm.setString(5,cobbs.getY1());
			stm.setString(6,cobbs.getX2());
			stm.setString(7,cobbs.getY2());
			stm.setString(8, cobbs.getK1());
			stm.setString(9, cobbs.getK2());
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}

	/**
	 * ����imgIdɾ��cobbs��
	 * @param imgId
	 */
	public void deleteCobbs(String imgId)
	{
		connection = DBUtil.getConnection();
		String sql = "delete from cobbs where imgId = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setString(1, imgId);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, null);
		}
		
		
	};
	
	
	

}
