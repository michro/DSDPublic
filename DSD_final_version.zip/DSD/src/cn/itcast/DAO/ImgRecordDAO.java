package cn.itcast.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.itcast.Bean.ImgRecord;
import cn.itcast.util.DBUtil;

public class ImgRecordDAO {
	
	private Connection connection;

	/**
	 * ����recordidȡ����¼ͼƬ
	 * @param RecordId
	 * @return
	 */
	public ImgRecord findImgRecord(String recordId)
	{
		ImgRecord imgRecord = null;
		connection = DBUtil.getConnection();
		String sql = "select * from imgrecord where recordId = '" + recordId + "'";		
		PreparedStatement stm = null;
		ResultSet rs = null;
		
		try {
			stm = connection.prepareStatement(sql);
			rs = stm.executeQuery();
			if(rs.next())
			{
				imgRecord = new ImgRecord();
				imgRecord.setId(rs.getString("id"));
				imgRecord.setPhotoSrc(rs.getString("photoSrc"));
				imgRecord.setRecordId(rs.getString("recordId"));
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, rs);
		}	
		return imgRecord;
	}
	
	/**
	 * �����¼
	 * @param imgRecord
	 */
	public void writeImgRecord(ImgRecord imgRecord)
	{
		connection = DBUtil.getConnection();
		String sql = "insert into imgrecord (id, recordId, photoSrc) values (?,?,?)";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setString(1, imgRecord.getId());
			stm.setString(2, imgRecord.getRecordId());
			stm.setString(3, imgRecord.getPhotoSrc());
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
	/**
	 * ���ݼ�¼Idɾ����¼
	 * @param RecordId
	 */
	public void deleteImgRecord(int recordId)
	{
		connection = DBUtil.getConnection();
		String sql = "delete from imgrecord where recordId = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, recordId);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
}
