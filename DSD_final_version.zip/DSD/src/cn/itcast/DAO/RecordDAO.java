package cn.itcast.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import cn.itcast.Bean.Record;
import cn.itcast.util.DBUtil;

public class RecordDAO {

	private Connection  connection;
	
	/**
	 * �����û�����ȡ���м�¼
	 * @param Username �û���
	 * @return
	 */
	public ArrayList<Record> getRecord(String username)
	{
		ArrayList<Record> records = new ArrayList<Record>();
		connection = DBUtil.getConnection();
		String sql = "select * from record where username = '" + username + "'";
		PreparedStatement stm = null;
		ResultSet rs = null;
		
		try {
			stm = connection.prepareStatement(sql);
			rs = stm.executeQuery();
			while(rs.next())
			{
				Record record = new Record();
				record.setId(rs.getString("id"));
				record.setUsername(rs.getString("username"));
				record.setCobbNums(rs.getInt("cobbNums"));
				record.setLenkeRes(rs.getInt("lenkeRes"));
				records.add(record);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBUtil.CloseDB(connection, stm, rs);
		}
		
		return records;
	}

	/**
	 * �����¼
	 * @param record �����¼
	 */
	public void writeRecord(Record record)
	{
		connection = DBUtil.getConnection();
		String sql = "insert into record (id, username, cobbNums, lenkeRes) values (?,?,?,?)";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setString(1, record.getId());
			stm.setString(2, record.getUsername());
			stm.setInt(3, record.getCobbNums());
			stm.setInt(4, record.getLenkeRes());
			stm.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, null);
		}	
	}

	/**
	 * ���ݼ�¼��Idɾ����¼
	 * @param Id
	 */
	public void deleteRecord(int id)
	{
		connection = DBUtil.getConnection();
		String sql = "delete from record where id = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, id);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}
	
	public void update(String recordId, int cobbNums, int lenkeRes)
	{
		connection = DBUtil.getConnection();
		String sql = "update record set `cobbNums` = ? , `lenkeRes` = ? where `id` = ?";
		PreparedStatement stm = null;
		
		try {
			stm = connection.prepareStatement(sql);
			stm.setInt(1, cobbNums);
			stm.setInt(2, lenkeRes);
			stm.setString(3, recordId);
			stm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			DBUtil.CloseDB(connection, stm, null);
		}
	}

}
