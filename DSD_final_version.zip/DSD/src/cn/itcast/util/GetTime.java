package cn.itcast.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GetTime {
	
	public static String GetTimeDate()
	{
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd HHmmss");
	    String dateString = formatter.format(date);
	    String newDateString = dateString.split(" ")[0] + dateString.split(" ")[1];
	    return newDateString;
	}
	
}
