package cn.itcast.util;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;



public class Java2Py {
	
//	static final String ROOTPATH = "";
	
	// path = {filepath, imgpath} default + ROOTPATH when run code
	static String[] FRCNN_Path = {"D:\\PycharmProjects\\faster-rcnn-keras-master\\predict.py", "D:\\PycharmProjects\\faster-rcnn-keras-master\\img\\after\\0003.jpg"};
	static String[] GetCobbline_Path = {"D:\\PycharmProjects\\LuckyDogs\\getcobb.py", "D:\\PycharmProjects\\LuckyDogs\\test_image\\7.jpg"};
//	String[] XRay_Try_Path = {"NONE", "NONE"};
	
	public static void setImgPath(String[] Path, String img) {
		Path[1] = img;
		
	}
	
	public static void main(String[] args) {
		Java2Py j2p = new Java2Py();
//		j2p.runFRCNN();
//		j2p.runGetCobbline();
//		j2p.runXRayTry();
//		j2p.runFRCNN(j2p.FRCNN_Path);
//		j2p.runGetCobbline(j2p.GetCobbline_Path);
		String line = null;
//		line=  j2p.runUbuntuCommand();
//		line = j2p.runFRCNN(FRCNN_Path);
		line = j2p.runGetCobbline(GetCobbline_Path);
				
		System.out.println(line);
	}
	
	/**
	 * run faster-rcnn-keras-master
	 * the project from lgp's team, and train model with faster-rcnn
	 */
	public String runFRCNN(String[] Path) {
			String[] argvs = new String[] {"python", Path[0], Path[1]};
			String nextline = null;
			String line = null;
			try {					
				Process process = Runtime.getRuntime().exec(argvs);			
				BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
				while ((nextline = br.readLine()) != null) {
					
					// do nothing
					line = nextline;
//					System.out.println(line);
					
				}
				br.close();
				process.waitFor();
			} catch (IOException e) {
				e.printStackTrace();
			}
			catch (InterruptedException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
//			System.out.println("done");
			return line;
	}

	
	
	/**
	 * run DSDtest_lll
	 * lll's team project
	 */
	public String runGetCobbline(String[] Path) {
//		String rootPath = "D:\\PycharmProjects\\DSDtest_lll";
		//ROOTPATH + Path[0]
		String[] argvs = new String[] {"python", Path[0], Path[1]};
		String line = null;
		String nextline = null;
		try {
			Process process = Runtime.getRuntime().exec(argvs);
			BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
			
			while((nextline = br.readLine()) != null) {
//				System.out.println(line);
				// do nothing
				line = nextline;
			}
			br.close();
			process.waitFor();
			
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
			
		} catch (InterruptedException e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
		return line;
		
	}
	
	
	/**
	 * run 
	 * mck's team project
	 * ABANDON
	 * @throws IOException 
	 */
	
	public String runUbuntuCommand() {
		String line = null;
		String command = "D:\\putty.exe -ssh whitish@192.168.111.129 -pw 199904.16 -m D:\\command.txt";
		Runtime run = Runtime.getRuntime();
		try {
			Process process = run.exec(command);
			InputStream in = process.getInputStream();
			InputStreamReader inreader = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(inreader);
			StringBuffer sb = new StringBuffer();
            String message;
            while((message = br.readLine()) != null) {
                sb.append(message);
                System.out.println(message);
            }
            File file = new File("D:\\eclipse-workspace\\DSD\\RecordImg\\result.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            line = bufferedReader.readLine();
            
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return line;
	}

	
	
	public static String runAlgorithm(int num, String imgFilePath) {
		// TODO Auto-generated method stub
		Java2Py j2p = new Java2Py();
		String result = null;
		
		switch (num) {
		case 1:
			FRCNN_Path[1] = imgFilePath;
			result = j2p.runFRCNN(FRCNN_Path);
			break;
		case 2:
			result = j2p.runUbuntuCommand();
			break;
		case 3:
			GetCobbline_Path[1] = imgFilePath;
			result = j2p.runGetCobbline(GetCobbline_Path);
			break;
		default:
			break;
		}
		return result;
	}
	

	
}
