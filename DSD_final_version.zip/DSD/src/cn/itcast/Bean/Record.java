package cn.itcast.Bean;

public class Record {
	
	private String id;
	private String username;
	private int cobbNums;
	private int lenkeRes;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getCobbNums() {
		return cobbNums;
	}
	public void setCobbNums(int cobbNums) {
		this.cobbNums = cobbNums;
	}
	public int getLenkeRes() {
		return lenkeRes;
	}
	public void setLenkeRes(int lenkeRes) {
		this.lenkeRes = lenkeRes;
	}
	public Record(String id, String username, int cobbNums, int lenkeRes) {
		super();
		this.id = id;
		this.username = username;
		this.cobbNums = cobbNums;
		this.lenkeRes = lenkeRes;
	}
	public Record() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Record [id=" + id + ", username=" + username + ", cobbNums=" + cobbNums + ", lenkeRes=" + lenkeRes
				+ "]";
	}
	
	
}
