package cn.itcast.Bean;

public class ImgRecord {
	
	private String id;
	private String recordId;
	private String photoSrc;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getPhotoSrc() {
		return photoSrc;
	}
	public void setPhotoSrc(String photoSrc) {
		this.photoSrc = photoSrc;
	}
	@Override
	public String toString() {
		return "ImgRecord [id=" + id + ", recordId=" + recordId + ", photoSrc=" + photoSrc + "]";
	}
	public ImgRecord(String id, String recordId, String photoSrc) {
		super();
		this.id = id;
		this.recordId = recordId;
		this.photoSrc = photoSrc;
	}
	public ImgRecord() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
