package cn.itcast.Bean;

public class Algorithm {
	
	private int algorithmId;
	private int index;
	public int getAlgorithmId() {
		return algorithmId;
	}
	public void setAlgorithmId(int algorithmId) {
		this.algorithmId = algorithmId;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public Algorithm(int algorithmId, int index) {
		super();
		this.algorithmId = algorithmId;
		this.index = index;
	}
	public Algorithm() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Algorithm [algorithmId=" + algorithmId + ", index=" + index + "]";
	}
	
	
	
}
