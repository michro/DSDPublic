package cn.itcast.Bean;

public class Cobbs {
	
	private String id;
	private String imgId;
	private String cobbValue;
	private String x1;
	private String y1;
	private String x2;
	private String y2;
	private String k1;
	private String k2;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public String getCobbValue() {
		return cobbValue;
	}
	public void setCobbValue(String cobbValue) {
		this.cobbValue = cobbValue;
	}
	public String getX1() {
		return x1;
	}
	public void setX1(String x1) {
		this.x1 = x1;
	}
	public String getY1() {
		return y1;
	}
	public void setY1(String y1) {
		this.y1 = y1;
	}
	public String getX2() {
		return x2;
	}
	public void setX2(String x2) {
		this.x2 = x2;
	}
	public String getY2() {
		return y2;
	}
	public void setY2(String y2) {
		this.y2 = y2;
	}
	public String getK1() {
		return k1;
	}
	public void setK1(String k1) {
		this.k1 = k1;
	}
	public String getK2() {
		return k2;
	}
	public void setK2(String k2) {
		this.k2 = k2;
	}
	@Override
	public String toString() {
		return "Cobbs [id=" + id + ", imgId=" + imgId + ", cobbValue=" + cobbValue + ", x1=" + x1 + ", y1=" + y1
				+ ", x2=" + x2 + ", y2=" + y2 + ", k1=" + k1 + ", k2=" + k2 + "]";
	}
	public Cobbs(String id, String imgId, String cobbValue, String x1, String y1, String x2, String y2, String k1,
			String k2) {
		super();
		this.id = id;
		this.imgId = imgId;
		this.cobbValue = cobbValue;
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.k1 = k1;
		this.k2 = k2;
	}
	public Cobbs() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
