一次检测返回结果：  data="BASE64encode?type,n,cobb1,x1,y1,k1,x2,y2,k2,cobb2,x3,y3,k3,x4,y4,k4"
patient.jsp 查看历史记录  历史记录的格式 “一次检测返回结果  一次检测返回结果  一次检测返回结果"

医生的点赞  dianzanservlet
医生的修改检测结果 一次检测返回结果


